﻿# Proyecto Preparado para Transferir

Esta es una version limpia del proyecto Playas RD Flutter, lista para transferir a Mac.

## Instrucciones en Mac

1. Extrae este ZIP en tu Mac
2. Renombra la carpeta a playas_rd_flutter (sin el sufijo _para_transferir)
3. Abre Terminal y navega al proyecto:
   cd playas_rd_flutter

4. Instala dependencias:
   flutter pub get
   cd ios && pod install && cd ..

5. Sigue la guia completa en: GUIA_COMPILAR_MAC.md

## Notas Importantes

- Los archivos de build se regeneraran en Mac
- Las dependencias de CocoaPods se instalaran automaticamente
- El archivo .env NO esta incluido (configuralo en Mac si lo necesitas)
- Los certificados de Android NO estan incluidos (seguridad)

## Fecha de preparacion

2025-11-29 21:47:07

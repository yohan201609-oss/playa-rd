import Flutter
import UIKit
import GoogleMaps

@main
@objc class AppDelegate: FlutterAppDelegate {
  override func application(
    _ application: UIApplication,
    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
  ) -> Bool {
    // Configurar Google Maps API Key
    // NOTA: Reemplaza esta API Key con tu propia Google Maps API Key para iOS
    // La puedes obtener en: https://console.cloud.google.com/google/maps-apis/credentials
    GMSServices.provideAPIKey("AIzaSyCpUfP7yerqjzXPMSxGU4I50OpQATcrqQ4")
    
    GeneratedPluginRegistrant.register(with: self)
    return super.application(application, didFinishLaunchingWithOptions: launchOptions)
  }
}
